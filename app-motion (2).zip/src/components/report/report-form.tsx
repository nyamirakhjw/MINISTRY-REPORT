"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useLocale, useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Input, Select, Textarea } from "@/components/ui/input";
import { Collapse } from "@/components/ui/collapse";
import { DrawnCheck } from "@/components/ui/drawn-check";
import { Segmented } from "@/components/ui/segmented";
import { ReportCard, type ReportCardData } from "@/components/report/report-card";
import { Field } from "@/components/forms/field";
import { Stepper } from "@/components/forms/stepper";
import { applyLogCarryoverAction, submitReportAction } from "@/lib/actions/report";
import { COMMENT_WORD_LIMIT, countWords } from "@/lib/domain/words";
import { isPioneer, type Category } from "@/lib/domain/categories";
import { floorHours, formatHMS } from "@/lib/domain/log";
import { formatDateTime, formatMonth } from "@/lib/format";

interface Props { month: string; options: Category[]; windowNote: string; logSeconds?: number; card: Omit<ReportCardData, "month" | "category" | "participated" | "hours" | "studies"> }
type Step = "edit" | "review" | "done";

export function ReportForm({ month, options, windowNote, logSeconds = 0, card }: Props) {
  const t = useTranslations("report");
  const cat = useTranslations("categories");
  const te = useTranslations("errors");
  const tc = useTranslations("card");
  const locale = useLocale();
  const router = useRouter();
  // One key per form so a double tap or a retry after a weak connection creates one report (REP-10).
  const requestId = React.useRef(crypto.randomUUID());
  const [step, setStep] = React.useState<Step>("edit");
  const [category, setCategory] = React.useState<Category>(options.find((o) => o !== "publisher") ?? "publisher");
  const [participated, setParticipated] = React.useState<"yes" | "no" | "">("");
  // Pre-filled from the daily log (REP-04); still editable, and editing it is exactly what skips the carry-over (§6.5).
  const [hours, setHours] = React.useState(logSeconds > 0 ? String(floorHours(logSeconds)) : "");
  const [studies, setStudies] = React.useState(0);
  const [comment, setComment] = React.useState("");
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [serverError, setServerError] = React.useState<string | null>(null);
  const [doneAt, setDoneAt] = React.useState<string | null>(null);
  const [pending, start] = React.useTransition();
  const summary = React.useRef<HTMLDivElement>(null);

  const pioneer = isPioneer(category);
  const words = countWords(comment);
  const saidNo = !pioneer && participated === "no";
  const hoursNum = hours === "" ? null : Number(hours);

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!pioneer && participated === "") e.participated = te("participation_required");
    if (pioneer && (hoursNum === null || !Number.isInteger(hoursNum) || hoursNum < 0 || hoursNum > 744)) e.hours = te(hoursNum === null ? "hours_required" : "hours_out_of_range");
    if (!saidNo && words > COMMENT_WORD_LIMIT) e.comment = te("comment_too_long");
    setErrors(e);
    if (Object.keys(e).length > 0) { setTimeout(() => summary.current?.focus(), 0); return false; }
    return true;
  }

  function submit() {
    setServerError(null);
    start(async () => {
      const r = await submitReportAction({
        month, category, request_id: requestId.current,
        participated: pioneer ? null : participated === "yes",
        hours: pioneer ? hoursNum : null,
        studies: saidNo ? 0 : studies,
        comment: saidNo ? "" : comment.trim(),
      });
      if (r.ok) {
        if (pioneer && r.data) void applyLogCarryoverAction(r.data); // best-effort; a failure here never blocks the confirmation
        setDoneAt(new Date().toISOString()); setStep("done"); router.refresh(); return;
      }
      setServerError(r.code === "earlier_month_pending" ? (r.hint ? te("earlier_month_pending", { month: formatMonth(r.hint, locale) }) : te("unknown")) : te.has(r.code) ? te(r.code) : te("unknown"));
      setStep("edit");
    });
  }

  if (step === "done") {
    // The report-submitted moment (PRD v1.1 AM-10): the check draws, the words rise in turn, then the card settles in.
    const order = (n: number) => ({ "--i": n }) as React.CSSProperties;
    return (
      <div className="flex flex-col gap-5">
        <div role="status" className="rounded-lg border border-border bg-surface p-5">
          <DrawnCheck />
          <h2 className="m-enter mt-3 text-xl" style={order(2)}>{t("submittedTitle")}</h2>
          <p className="m-enter mt-2" style={order(3)}>{t("submittedBody", { month: formatMonth(month, locale), time: formatDateTime(doneAt ?? new Date().toISOString(), locale) })}</p>
          <div className="m-enter mt-4" style={order(4)}><Button onClick={() => router.push("/app")}>{t("backHome")}</Button></div>
        </div>
        <section aria-labelledby="card-title" className="m-enter flex flex-col gap-3" style={order(5)}>
          <h2 id="card-title" className="text-xl">{tc("heading", { month: formatMonth(month, locale) })}</h2>
          <ReportCard data={{ ...card, month, category, participated: pioneer ? (hoursNum ?? 0) > 0 : participated === "yes", hours: pioneer ? hoursNum : null, studies: saidNo ? 0 : studies }} />
        </section>
      </div>
    );
  }

  if (step === "review") {
    const bigHours = pioneer && (hoursNum ?? 0) > 300;
    return (
      <div className="m-enter flex flex-col gap-5">
        <h2 className="text-xl">{t("reviewTitle")}</h2>
        <dl className="divide-y divide-border rounded-lg border border-border bg-surface">
          <Row k={t("month")} v={formatMonth(month, locale)} />
          <Row k={t("category")} v={cat(category)} />
          {pioneer ? <Row k={t("hours")} v={String(hoursNum)} /> : <Row k={t("participated")} v={participated === "yes" ? t("yes") : t("no")} />}
          {!saidNo && <Row k={t("studies")} v={String(studies)} />}
          {!saidNo && comment.trim() && <Row k={t("comment")} v={comment.trim()} />}
        </dl>
        <p className="text-muted-foreground">{windowNote}</p>
        {pioneer && hoursNum === 0 && <p role="alert" className="rounded-md border-2 border-warning p-3 font-semibold">{t("zeroHoursConfirm")}</p>}
        {bigHours && <p role="alert" className="rounded-md border-2 border-warning p-3 font-semibold">{t("bigHoursConfirm", { hours: hoursNum ?? 0 })}</p>}
        <p className="font-semibold">{t("lockWarning")}</p>
        <div className="flex flex-wrap gap-3">
          <Button onClick={submit} disabled={pending}>{pending ? t("submitting") : t("submit")}</Button>
          <Button variant="secondary" onClick={() => setStep("edit")} disabled={pending}>{t("edit")}</Button>
        </div>
      </div>
    );
  }

  const items = [...Object.entries(errors).map(([id, message]) => ({ id, message })), ...(serverError ? [{ id: "category", message: serverError }] : [])];
  return (
    <form onSubmit={(e) => { e.preventDefault(); if (validate()) setStep("review"); }} noValidate className="m-enter flex flex-col gap-6">
      {items.length > 0 && (
        <div ref={summary} role="alert" tabIndex={-1} className="rounded-md border-2 border-danger bg-surface p-4">
          <h2 className="text-lg text-danger">{te("summaryTitle")}</h2>
          <ul className="mt-2 list-disc pl-5">{items.map((i) => <li key={i.id}><a href={`#${i.id}`} className="font-semibold underline">{i.message}</a></li>)}</ul>
        </div>
      )}
      <p className="text-muted-foreground">{windowNote}</p>
      {options.length > 1 && (
        <Field id="category" label={t("category")}>
          <Select id="category" value={category} onChange={(e) => setCategory(e.target.value as Category)}>
            {options.map((o) => <option key={o} value={o}>{cat(o)}</option>)}
          </Select>
        </Field>
      )}
      {!pioneer ? (
        <div id="participated" tabIndex={-1} className="flex flex-col gap-2">
          <p className="text-base font-semibold" id="participated-label">{t("didYouParticipate")}</p>
          <Segmented label={t("didYouParticipate")} value={participated} onValueChange={(v) => setParticipated(v as "yes" | "no")} options={[{ value: "yes", label: t("yes") }, { value: "no", label: t("no") }]} />
          {errors.participated ? <p role="alert" className="text-sm font-semibold text-danger">{errors.participated}</p> : null}
        </div>
      ) : (
        <Field id="hours" label={t("hours")} hint={logSeconds > 0 ? t("hoursFromLog", { time: formatHMS(logSeconds) }) : t("hoursHint")} error={errors.hours}>
          <Input id="hours" inputMode="numeric" pattern="[0-9]*" value={hours} aria-invalid={!!errors.hours} onChange={(e) => setHours(e.target.value.replace(/\D/g, ""))} className="text-xl font-semibold tabular" />
        </Field>
      )}
      <Collapse open={!saidNo}>
        <div className="flex flex-col gap-6">
          <Field id="studies" label={t("studies")}>
            <Stepper id="studies" value={studies} onChange={setStudies} label={t("studies")} />
          </Field>
          <Field id="comment" label={t("comment")} optional optionalLabel={t("optional")} hint={t("commentHint")} error={errors.comment}>
            <Textarea id="comment" value={comment} onChange={(e) => setComment(e.target.value)} aria-invalid={!!errors.comment} aria-describedby="comment-count comment-hint" />
            <p id="comment-count" aria-live="polite" className={`text-sm tabular transition-colors ${words > COMMENT_WORD_LIMIT ? "font-semibold text-danger" : words >= COMMENT_WORD_LIMIT - 5 ? "font-semibold text-warning" : "text-muted-foreground"}`}>{t("wordCount", { count: words, max: COMMENT_WORD_LIMIT })}</p>
          </Field>
        </div>
      </Collapse>
      <Collapse open={saidNo}><p className="rounded-md bg-tint p-3">{t("noLocks")}</p></Collapse>
      <Button type="submit">{t("review")}</Button>
    </form>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between gap-4 p-3"><dt className="text-muted-foreground">{k}</dt><dd className="max-w-[60%] text-right font-semibold">{v}</dd></div>;
}
